#pragma once

namespace foobar
{
    struct Example
    {
        int getValue() const;
    };
}
