#include "example.h"

namespace foobar
{
    int Example::getValue() const
    {
        return 99;
    }
}
