#pragma once
#include<math.h>
#include<cmath>

namespace foobar
{
    struct Example
    {
        int getValue() const;
        float suma(float, float);
        float hipotenusa(float cateto1,float cateto2);
    };
        
}
float suma(float, float);
