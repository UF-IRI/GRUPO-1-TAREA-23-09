# `Nombre Proyecto` - Grupo `XX`
    Descripción del proyecto

### Integrantes
- 
- 
- 
- 
---
[![MacOS](https://github.com/UF-IRI/Plantilla_CMake_CPP/actions/workflows/macos.yml/badge.svg)](https://github.com/UF-IRI/Plantilla_CMake_CPP/actions/workflows/macos.yml)
[![Ubuntu](https://github.com/UF-IRI/Plantilla_CMake_CPP/actions/workflows/ubuntu.yml/badge.svg)](https://github.com/UF-IRI/Plantilla_CMake_CPP/actions/workflows/ubuntu.yml)
[![Windows](https://github.com/UF-IRI/Plantilla_CMake_CPP/actions/workflows/windows.yml/badge.svg)](https://github.com/UF-IRI/Plantilla_CMake_CPP/actions/workflows/windows.yml)
---
##### Universidad Favaloro - Introducción a la Redes e Internet
##### 2do Cuatrimestre - 2022